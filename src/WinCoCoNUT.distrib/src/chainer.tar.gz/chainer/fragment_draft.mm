# args=-absolute -l 100 -q NC_002745.fna.draft.shuffled /home/mibrahim/Myprojects/GenomeChainer/distChainerWithSourceLinux5/src/indexNC_003923
